# CISEM WORKSPACE FILE INVENTORY
> [NOTE: Directory listings are summarized to maintain strict under-400-line budget per file contract.]

| Relative File Path | Internal Header Version | Filename Version | Version Match Status |
| :--- | :--- | :--- | :--- |
| `cisem_core/2026-08-05__CISEM__CXP__CapabilityRegistry__V1.2.yaml` | `1.3` | `1.2` | MISMATCH (1.3 vs 1.2) |
| `cisem_core/2026-08-05__CISEM__CXP__CompletenessMatrix__V1.2.yaml` | `1.2` | `1.2` | MATCH |
| `cisem_core/2026-08-05__CISEM__CXP__IntentRegistry__V1.2.yaml` | `1.2` | `1.2` | MATCH |
| `cisem_core/2026-08-05__CISEM__CXP__Specification__V1.2.md` | `1.2` | `1.2` | MATCH |
| `cisem_core/2026-08-05__CISEM__CXP__StateTransitionMatrix__V1.3.yaml` | `1.3` | `1.3` | MATCH |
| `cisem_core/2026-08-05__CISEM__Universal_Workspace_and_Accountability_Registry__V1.25.yaml` | `1.25` | `1.25` | MATCH |
| `cisem_core/2026-08-05__CISEM__Universal_Workspace_and_Accountability_Registry__V1.30.yaml` | `1.30` | `1.30` | MATCH |
| `cisem_core/2026-08-05__CISEM__Universal_Workspace_and_Accountability_Registry__V1.31.yaml` | `1.31` | `1.31` | MATCH |
| `cisem_core/2026-08-05__CISEM__Universal_Workspace_and_Accountability_Registry__V1.37.yaml` | `1.37` | `1.37` | MATCH |
| `cisem_core/2026-08-05__CISEM__Universal_Workspace_and_Accountability_Registry__V1.39.yaml` | `1.39` | `1.39` | MATCH |
| `cisem_core/2026-08-05__CISEM__Universal_Workspace_and_Accountability_Registry__V1.4.yaml` | `1.4` | `1.4` | MATCH |
| `cisem_core/2026-08-05__CISEM__Universal_Workspace_and_Accountability_Registry__V1.40.yaml` | `1.40` | `1.40` | MATCH |
| `cisem_core/2026-08-05__CISEM__Universal_Workspace_and_Accountability_Registry__V1.41.yaml` | `1.41` | `1.41` | MATCH |
| `cisem_core/2026-08-05__CISEM__Universal_Workspace_and_Accountability_Registry__V1.42.yaml` | `1.42` | `1.42` | MATCH |
| `cisem_core/2026-08-05__CISEM__Universal_Workspace_and_Accountability_Registry__V1.43.yaml` | `1.43` | `1.43` | MATCH |
| `cisem_core/2026-08-05__CISEM__Universal_Workspace_and_Accountability_Registry__V1.44.yaml` | `1.44` | `1.44` | MATCH |
| `cisem_core/2026-08-07__CISEM__AntigravityLocal__CleanupEvidenceLog__V1.5.md` | `1.5` | `1.5` | MATCH |
| `cisem_core/2026-08-08__AntigravityLocal__GeminiBrain__SaaS_AutonomousSales_HardeningAndVerificationReport__V1.0.md` | `1.0` | `1.0` | MATCH |
| `cisem_core/2026-08-10__CISEM__AntigravityLocal__CleanupEvidenceLog__V1.6.md` | `1.6` | `1.6` | MATCH |
| `cisem_core/2026-08-14__CISEM__AntigravityLocal__BehavioralProfileRegistry__V1.0.yaml` | `1.0` | `1.0` | MATCH |
| `cisem_core/2026-08-14__GoogleAntigravity__CISEM__DeletionEvidenceLog__V1.0.yaml` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/CisemSync.py` | `1.3` | `UNVERSIONED` | MISMATCH (1.3 vs UNVERSIONED) |
| `cisem_core/CisemSyncSandbox.py` | `1.0` | `UNVERSIONED` | MISMATCH (1.0 vs UNVERSIONED) |
| `cisem_core/build.js` | `1.1` | `UNVERSIONED` | MISMATCH (1.1 vs UNVERSIONED) |
| `cisem_core/find_loose_pages.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/find_transcript_blink.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/ingest_wisdom.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/search_localstorage.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/search_page_return.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/search_registry_references.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/search_studio_viewport.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/search_toggledarkmode.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/test_chat_route.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/test_regex2.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/update_axioms.py` | `1.0` | `UNVERSIONED` | MISMATCH (1.0 vs UNVERSIONED) |
| `cisem_core/update_registry_v1.29.py` | `1.0` | `UNVERSIONED` | MISMATCH (1.0 vs UNVERSIONED) |
| `cisem_core/update_registry_v1.31.py` | `1.30` | `UNVERSIONED` | MISMATCH (1.30 vs UNVERSIONED) |
| `cisem_core/update_registry_v1.40.py` | `1.0` | `UNVERSIONED` | MISMATCH (1.0 vs UNVERSIONED) |
| `cisem_core/update_registry_v1.41.py` | `1.0` | `UNVERSIONED` | MISMATCH (1.0 vs UNVERSIONED) |
| `cisem_core/update_registry_v1.42.py` | `1.0` | `UNVERSIONED` | MISMATCH (1.0 vs UNVERSIONED) |
| `cisem_core/update_registry_v1.43.py` | `1.0` | `UNVERSIONED` | MISMATCH (1.0 vs UNVERSIONED) |
| `cisem_core/update_registry_v1.44.py` | `1.1` | `UNVERSIONED` | MISMATCH (1.1 vs UNVERSIONED) |
| `cisem_core/update_registry_v1.8.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/upload_to_drive.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/archive/2026-08-05__CISEM__Universal_Workspace_and_Accountability_Registry__V1.28.yaml` | `1.28` | `1.28` | MATCH |
| `cisem_core/archive/2026-08-05__CISEM__Universal_Workspace_and_Accountability_Registry__V1.38.yaml` | `1.38` | `1.38` | MATCH |
| `cisem_core/archive/2026-08-07__CISEM__AntigravityLocal__AxiomsAndPrinciples__V1.26.md` | `1.26` | `1.26` | MATCH |
| `cisem_core/archive/2026-08-07__CISEM__AntigravityLocal__AxiomsAndPrinciples__V1.27.md` | `1.27` | `1.27` | MATCH |
| `cisem_core/archive/2026-08-07__CISEM__AntigravityLocal__CleanupEvidenceLog__V1.4.md` | `1.4` | `1.4` | MATCH |
| `cisem_core/archive/Consolidated_Ingestion_Routing_and_4-Turn_Design_Accumulation_Plan__2026-08-06__V1.3.md` | `1.0` | `1.3` | MISMATCH (1.0 vs 1.3) |
| `cisem_core/archive/Consolidated_Ingestion_Routing_and_4-Turn_Design_Accumulation_Plan__2026-08-06__V1.4.md` | `1.0` | `1.4` | MISMATCH (1.0 vs 1.4) |
| `cisem_core/archive/Consolidated_Ingestion_Routing_and_Context-Driven_Accumulation_Plan__2026-08-06__V1.10.md` | `1.0` | `1.10` | MISMATCH (1.0 vs 1.10) |
| `cisem_core/archive/Consolidated_Ingestion_Routing_and_Context-Driven_Accumulation_Plan__2026-08-06__V1.11.md` | `1.0` | `1.11` | MISMATCH (1.0 vs 1.11) |
| `cisem_core/archive/Consolidated_Ingestion_Routing_and_Context-Driven_Accumulation_Plan__2026-08-06__V1.12.md` | `1.0` | `1.12` | MISMATCH (1.0 vs 1.12) |
| `cisem_core/archive/Consolidated_Ingestion_Routing_and_Context-Driven_Accumulation_Plan__2026-08-06__V1.13.md` | `1.0` | `1.13` | MISMATCH (1.0 vs 1.13) |
| `cisem_core/archive/Consolidated_Ingestion_Routing_and_Context-Driven_Accumulation_Plan__2026-08-06__V1.14.md` | `1.0` | `1.14` | MISMATCH (1.0 vs 1.14) |
| `cisem_core/archive/Consolidated_Ingestion_Routing_and_Context-Driven_Accumulation_Plan__2026-08-06__V1.15.md` | `1.0` | `1.15` | MISMATCH (1.0 vs 1.15) |
| `cisem_core/archive/Consolidated_Ingestion_Routing_and_Context-Driven_Accumulation_Plan__2026-08-06__V1.16.md` | `1.0` | `1.16` | MISMATCH (1.0 vs 1.16) |
| `cisem_core/archive/Consolidated_Ingestion_Routing_and_Context-Driven_Accumulation_Plan__2026-08-06__V1.5.md` | `1.0` | `1.5` | MISMATCH (1.0 vs 1.5) |
| `cisem_core/archive/Consolidated_Ingestion_Routing_and_Context-Driven_Accumulation_Plan__2026-08-06__V1.6.md` | `1.0` | `1.6` | MISMATCH (1.0 vs 1.6) |
| `cisem_core/archive/Consolidated_Ingestion_Routing_and_Context-Driven_Accumulation_Plan__2026-08-06__V1.8.md` | `1.0` | `1.8` | MISMATCH (1.0 vs 1.8) |
| `cisem_core/archive/Consolidated_Ingestion_Routing_and_Context-Driven_Accumulation_Plan__2026-08-06__V1.9.md` | `1.0` | `1.9` | MISMATCH (1.0 vs 1.9) |
| `cisem_core/archive/Gate_Hardening_Context-Adaptive_Layer_Ingestion_Sanitization_Walkthrough__2026-08-06__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/archive/Sandbox_Trial_for_Multi-Model_Code_Review_and_Path_Reconciliation_Plan__2026-08-06__V1.2.md` | `UNSTATED` | `1.2` | MISMATCH (UNSTATED vs 1.2) |
| `cisem_core/archive/Sandbox_trial_for_Multi-Model_Code_Review_and_Path_Reconciliation_Walkthrough__2026-08-06__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/archive/Sandbox_trial_for_Multi-Model_Code_Review_and_Path_Reconciliation_Walkthrough__2026-08-06__V1.1.md` | `UNSTATED` | `1.1` | MISMATCH (UNSTATED vs 1.1) |
| `cisem_core/archive/Threshold_Entry_Point_and_Naming_Enforcement_Plan__2026-08-06__V1.2.md` | `UNSTATED` | `1.2` | MISMATCH (UNSTATED vs 1.2) |
| `cisem_core/archive/Threshold_Integration_and_Workspace_Restructuring_Walkthrough__2026-08-06__V1.3.md` | `UNSTATED` | `1.3` | MISMATCH (UNSTATED vs 1.3) |
| `cisem_core/archive/Threshold_Integration_and_Workspace_Restructuring_Walkthrough__2026-08-06__V1.4.md` | `UNSTATED` | `1.4` | MISMATCH (UNSTATED vs 1.4) |
| `cisem_core/archive/Threshold_Integration_and_Workspace_Restructuring_Walkthrough__2026-08-06__V1.5.md` | `UNSTATED` | `1.5` | MISMATCH (UNSTATED vs 1.5) |
| `cisem_core/archive/Witness_Positioning_Tracker_Implementation_and_Verification_Walkthrough__2026-08-06__V1.0.md` | `1.0` | `1.0` | MATCH |
| `cisem_core/canon/00__INDEX__Canon__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/01__CHARTER__Goal_and_Scope__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/I1__CsAg__Governance_and_Method__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/I1a__CsAg__Actor_Failure_Audit__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/I2__CsAg__Identity_and_Tenancy__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/I3__CsAg__Data_and_Persistence__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/I4__CsAg__Entitlement_and_Templates__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/I5__CsAg__Vertical_and_Product__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/I6__CsAg__Surface_and_Experience__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/I7__CsAg__Operations_and_Cadence__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/P1__Pipeline__Intent_to_Sustained__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/PARKED.md` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/canon/R00__Register__Awaiting_Ratification__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/README.md` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/canon/S00__Register__Solution_Register_and_Record_Format__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/S00__Template__Solution_Record__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/S02__GovernancePlane__Definition__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/U0A__Core__Tier_Separation__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/U0B__Core__Naming_and_Numbering_Grid__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/U0C__Core__Invariant_and_Pocket_Formats__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/U1__Core__Governance_and_Method__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/U2__Core__Identity_and_Tenancy__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/U3__Core__Data_and_Persistence__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/U4__Core__Entitlement_and_Templates__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/U5__Core__Vertical_and_Product__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/U6__Core__Surface_and_Experience__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/U7__Core__Operations_and_Cadence__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/W00__Digest__Principles_and_Failure_Modes__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/W01__Propagation__Alignment__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/W02__Digest__Session_Lessons_Converted__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/cycle_grid.md` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/canon/_superseded/CISEM_Operating_Playbook.md` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/canon/_superseded/CISEM_Session_Review_and_Gap_Closure_Plan.md` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/canon/_superseded/CISEM_Structure_and_Frontend_Doctrine.md` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/canon/_superseded/CISEM__A0.2__Core_Cycle_Law__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/_superseded/CISEM__A0__Canon_Addressing_System__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/_superseded/CISEM__A0__Canon_Addressing_System__V1.1.md` | `UNSTATED` | `1.1` | MISMATCH (UNSTATED vs 1.1) |
| `cisem_core/canon/_superseded/CISEM__A__Canon_and_Governance__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/_superseded/CISEM__B__Identity_and_Tenancy__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/_superseded/CISEM__C__Data_and_Persistence__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/_superseded/CISEM__D__Entitlement_and_Templates__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/_superseded/CISEM__E__Vertical_and_Product__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/_superseded/CISEM__F__Surface_and_UX__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/_superseded/CISEM__G__Operations_and_Cadence__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/canon/_superseded/CISEM__README__Canon_Index__V1.1.md` | `UNSTATED` | `1.1` | MISMATCH (UNSTATED vs 1.1) |
| `cisem_core/code/2026-08-08__AntigravityLocal__YarivHuman__SaaS_AutonomousSales_ChatApiRoute__V1.0.ts` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/code/2026-08-08__AntigravityLocal__YarivHuman__SaaS_AutonomousSales_ChatApiRoute__V1.1.ts` | `UNSTATED` | `1.1` | MISMATCH (UNSTATED vs 1.1) |
| `cisem_core/code/2026-08-08__AntigravityLocal__YarivHuman__SaaS_AutonomousSales_ChatApiRoute__V1.2.ts` | `UNSTATED` | `1.2` | MISMATCH (UNSTATED vs 1.2) |
| `cisem_core/code/2026-08-08__AntigravityLocal__YarivHuman__SaaS_AutonomousSales_ChatWidgetComponent__V1.0.tsx` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/code/2026-08-08__AntigravityLocal__YarivHuman__SaaS_GeminiMultiModalEmbeddingService__V1.0.py` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/code/2026-08-08__AntigravityLocal__YarivHuman__SaaS_PGVectorMultiTenantSearchService__V1.0.py` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/code/2026-08-08__AntigravityLocal__YarivHuman__SaaS_PayloadCatalogEnrichmentHook__V1.0.ts` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/code/2026-08-08__AntigravityLocal__YarivHuman__SaaS_PayloadMediaCollectionSchema__V1.0.ts` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/code/2026-08-08__AntigravityLocal__YarivHuman__SaaS_RootLayoutComponent__V1.0.tsx` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/cron/quota_warning_notifier.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/cron/reset_tenant_quotas.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/cxp/2026-08-05__GoogleAntigravity__Cxp__CxpAdapter__V0.1.py` | `0.1` | `0.1` | MATCH |
| `cisem_core/cxp/2026-08-05__GoogleAntigravity__Cxp__CxpWatcher__V0.1.py` | `0.4` | `0.1` | MISMATCH (0.4 vs 0.1) |
| `cisem_core/cxp/2026-08-05__GoogleAntigravity__Cxp__GasOrchestrator__V0.1.js` | `0.1` | `0.1` | MATCH |
| `cisem_core/cxp/2026-08-08__GeminiAI__AntigravityLocal__MultiTenantSaaSArchitectureReference__V1.0.md` | `1.0` | `1.0` | MATCH |
| `cisem_core/cxp/2026-08-08__GeminiAI__AntigravityLocal__SaaS_AutonomousSales_And_VectorSearch_Reference__V1.0.md` | `1.0` | `1.0` | MATCH |
| `cisem_core/cxp/2026-08-08__GeminiAI__AntigravityLocal__SaaS_LLM_Routers_Reference__V1.0.md` | `1.0` | `1.0` | MATCH |
| `cisem_core/cxp/2026-08-14__GoogleAntigravity__Cxp__WorkspaceReconciler__V0.7.py` | `0.7` | `0.7` | MATCH |
| `cisem_core/cxp/2026-08-14__GoogleAntigravity__Cxp__WorkspaceReconciler__V0.8.py` | `0.8` | `0.8` | MATCH |
| `cisem_core/cxp/download_drive_files.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/cxp/download_exchange_updates.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/cxp/download_subfolder_files.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/cxp/list_all_drive_files.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/cxp/list_and_download_2100.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/cxp/list_subfolder.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/cxp/test_drive.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/cxp/update_response.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/cxp/update_response_2100.py` | `0.1` | `UNVERSIONED` | MISMATCH (0.1 vs UNVERSIONED) |
| `cisem_core/planning/2026-08-07__CISEM__Planning__Specification__V1.0.md` | `1.0` | `1.0` | MATCH |
| `cisem_core/planning/2026-08-07__GoogleAntigravity__Planning__PlanIngestor__V0.2.py` | `0.2` | `0.2` | MATCH |
| `cisem_core/planning/2026-08-08__AntigravityLocal__YarivHuman__EnterpriseScaleArchitectureBlueprint__V1.0.md` | `1.0` | `1.0` | MATCH |
| `cisem_core/planning/2026-08-08__AntigravityLocal__YarivHuman__KnowledgeManagementAndPlatformDnaEnforcement__V1.0.md` | `1.0` | `1.0` | MATCH |
| `cisem_core/planning/2026-08-08__AntigravityLocal__YarivHuman__PersonaAuditSandboxPositioning__V1.0.md` | `1.0` | `1.0` | MATCH |
| `cisem_core/planning/2026-08-08__AntigravityLocal__YarivHuman__ProjectManagementAndAccountabilityFramework__V1.0.md` | `1.0` | `1.0` | MATCH |
| `cisem_core/planning/2026-08-08__AntigravityLocal__YarivHuman__SandboxSystemSchemaAndStructure__V1.0.md` | `1.0` | `1.0` | MATCH |
| `cisem_core/planning/2026-08-08__AntigravityLocal__YarivHuman__SandboxThresholdProtocol__V1.0.md` | `1.0` | `1.0` | MATCH |
| `cisem_core/planning/2026-08-08__AntigravityLocal__YarivHuman__UniquePlatformMechanismsUsageReport__V1.0.md` | `1.0` | `1.0` | MATCH |
| `cisem_core/planning/2026-08-09__AntigravityLocal__YarivHuman__ModelRouterArchitectureBlueprint__V1.0.md` | `1.0` | `1.0` | MATCH |
| `cisem_core/planning/2026-08-09__Sonnet__YarivHuman__AX70000_StatisticalMaturityAndSWIFT_GeminiBuildPackage__V1.0.md` | `1.0` | `1.0` | MATCH |
| `cisem_core/planning/2026-08-09__Sonnet__YarivHuman__CruelReview_WhatExistsAndPendingPlans__V1.0.md` | `1.0` | `1.0` | MATCH |
| `cisem_core/planning/2026-08-10__CISEM__AntigravityLocal__GovernanceHardeningPlan__V1.6.md` | `UNSTATED` | `1.6` | MISMATCH (UNSTATED vs 1.6) |
| `cisem_core/planning/2026-08-10__Gemini3.5__YarivHuman__CoreSpiralMethodologySpecification__V1.0.md` | `1.0` | `1.0` | MATCH |
| `cisem_core/platform_core/2026-08-10__CISEM__AntigravityLocal__CisemConfig__V1.0.py` | `1.0` | `1.0` | MATCH |
| `cisem_core/platform_core/2026-08-10__CISEM__AntigravityLocal__GraphifyDependencyMapper__V1.0.py` | `1.0` | `1.0` | MATCH |
| `cisem_core/platform_core/2026-08-10__CISEM__AntigravityLocal__UserJourneySimulator__V1.0.py` | `1.0` | `1.0` | MATCH |
| `cisem_core/platform_core/2026-08-10__Gemini3.5__YarivHuman__PlatformCoreReadme__V1.0.md` | `1.0` | `1.0` | MATCH |
| `cisem_core/platform_core/2026-08-14__CISEM__AntigravityLocal__ContinuousAuditorDaemon__V1.3.py` | `1.3` | `1.3` | MATCH |
| `cisem_core/platform_core/2026-08-14__CISEM__AntigravityLocal__ContinuousAuditorLivenessCheck__V1.0.py` | `1.0` | `1.0` | MATCH |
| `cisem_core/platform_core/2026-08-14__CISEM__AntigravityLocal__E1_StructuralDriftCheck__V1.0.py` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/platform_core/2026-08-14__CISEM__AntigravityLocal__E2_ApplyMigration__V1.0.py` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/platform_core/cisem_gate.py` | `2.8` | `UNVERSIONED` | MISMATCH (2.8 vs UNVERSIONED) |
| `cisem_core/platform_core/template_propagation_scheduler.py` | `1.2` | `UNVERSIONED` | MISMATCH (1.2 vs UNVERSIONED) |
| `cisem_core/protocols/2026-08-09__CISEM__DecisionMaturityPipeline__V1.0.md` | `1.0` | `1.0` | MATCH |
| `cisem_core/routing/src/index.ts` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/sandbox/2026-08-09__AntigravityLocal__YarivHuman__TenantContextValidationVerificationScript__V1.0.py` | `1.0` | `1.0` | MATCH |
| `cisem_core/sandbox/CisemATV.py` | `1.1` | `UNVERSIONED` | MISMATCH (1.1 vs UNVERSIONED) |
| `cisem_core/sandbox/CisemAuditor.py` | `2.3` | `UNVERSIONED` | MISMATCH (2.3 vs UNVERSIONED) |
| `cisem_core/sandbox/CisemSanitizer.py` | `1.0` | `UNVERSIONED` | MISMATCH (1.0 vs UNVERSIONED) |
| `cisem_core/sandbox/parking_vault_draft.yaml` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/sandbox/persona_registry_draft.yaml` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/sandbox/persona_scenario_map.yaml` | `1.0` | `UNVERSIONED` | MISMATCH (1.0 vs UNVERSIONED) |
| `cisem_core/sandbox/recovered_vault.yaml` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/security/2026-08-14__CisemCsAg__Security__SecretLiteralLinter__V1.0.py` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/security/2026-08-14__CisemCsAg__Security__SecretLiteralLinter__V1.1.py` | `UNSTATED` | `1.1` | MISMATCH (UNSTATED vs 1.1) |
| `cisem_core/security/2026-08-14__CisemCsAg__Security__TenantContextHmacVerification__V1.0.py` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/security/G6_connection_identity_report.md` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/security/cisem_db.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/security/e3_drift_check.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/security/e4_policy_lint.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/solution_core/2026-08-10__Gemini3.5__YarivHuman__SolutionCoreReadme__V1.0.md` | `1.0` | `1.0` | MATCH |
| `cisem_core/tools/audit_rls_policies.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/tools/generate_reviewer_pack.py` | `1.2` | `UNVERSIONED` | MISMATCH (1.2 vs UNVERSIONED) |
| `cisem_core/tools/package_reviewer_export.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/tools/replay_webhook_event.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `cisem_core/trials/2026-08-09__Sonnet__YarivHuman__Trial001Runner__V1.0.ts` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/trials/trial_registry.yaml` | `1.0` | `UNVERSIONED` | MISMATCH (1.0 vs UNVERSIONED) |
| `cisem_core/trials/conclusions/TRIAL-001__ConclusionReport__Sonnet__YarivHuman__ModelRouting__V1.0.md` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `cisem_core/trials/research/2026-08-09__Sonnet__YarivHuman__TRIAL-001_ModelRoutingResearchBrief__V1.0.md` | `1.0` | `1.0` | MATCH |
| `cisem_core/workers/webhook_retry_worker.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `backend/README.md` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `backend/src/backend/2026-08-14__CisemCsAg__Backend__UserTenantClaimBackfill__V1.0.py` | `UNSTATED` | `1.0` | MISMATCH (UNSTATED vs 1.0) |
| `backend/src/backend/2026-08-14__CisemCsAg__Backend__UserTenantClaimBackfill__V1.1.py` | `UNSTATED` | `1.1` | MISMATCH (UNSTATED vs 1.1) |
| `backend/src/backend/__init__.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `backend/src/backend/dto_models.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `backend/src/backend/embedding_service.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `backend/src/backend/main.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `backend/src/backend/mock_fixtures.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `backend/src/backend/parking_vault_router.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `backend/src/backend/pricing_engine.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `backend/src/backend/provisioning.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `backend/src/backend/scraper_engine.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `backend/src/backend/seed_db.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `backend/src/backend/stock_verifier.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `backend/src/backend/vector_search_service.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `backend/src/backend/utils/webhook_verifier.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `backend/tests/test_tenancy_rls.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |
| `backend/tests/test_tenant_middleware.py` | `UNSTATED` | `UNVERSIONED` | OK (UNVERSIONED) |