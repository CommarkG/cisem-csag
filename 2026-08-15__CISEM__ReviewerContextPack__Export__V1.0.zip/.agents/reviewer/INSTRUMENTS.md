# CISEM SECURITY AND GOVERNANCE INSTRUMENTS
> Derived dynamically from repository scan.

| Instrument Name | Relative File Path | Invoker Boundary | Failure Behavior | Proof Status |
| :--- | :--- | :--- | :--- | :--- |
| `cisem_gate.py` | `cisem_core/platform_core/cisem_gate.py` | `2026-08-06__AntigravityLocal__YarivHuman__Gate_Hardening_Context_Adaptive_Layer_Ingestion_Sanitization_Persona_Coverage_Gaps_Resolution_Walkthrough__V1.0.md` | Exits with code 1 / `gate_block()` | UNPROVEN |
| `SecretLiteralLinter` | `cisem_core/security/2026-08-14__CisemCsAg__Security__SecretLiteralLinter__V1.1.py` | `cisem_core\platform_core\cisem_gate.py` | NO EXPLICIT FAILURE BEHAVIOR DETECTED | UNPROVEN |
| `ContinuousAuditorDaemon` | `cisem_core/platform_core/2026-08-14__CISEM__AntigravityLocal__ContinuousAuditorDaemon__V1.3.py` | `.agents\skills\continuous-auditor\SKILL.md` | Writes status metrics to `cael_status.json` | UNPROVEN |
| `mbcs-verifier` | `.agents/skills/mbcs-verifier/SKILL.md` | `2026-08-10__AntigravityLocal__YarivHuman__Master_Completion_and_Simulated_User_Journeys_Walkthrough__V1.1.md` | NO EXPLICIT FAILURE BEHAVIOR DETECTED | UNPROVEN |
| `pgvector-partition-auditor` | `.agents/skills/pgvector-partition-auditor/SKILL.md` | `2026-08-10__AntigravityLocal__YarivHuman__Master_Completion_and_Simulated_User_Journeys_Walkthrough__V1.1.md` | NO EXPLICIT FAILURE BEHAVIOR DETECTED | UNPROVEN |
| `CisemAuditor.py` | `cisem_core/sandbox/CisemAuditor.py` | `2026-08-06__AntigravityLocal__YarivHuman__Gate_Hardening_Context_Adaptive_Layer_Ingestion_Sanitization_Persona_Coverage_Gaps_Resolution_Walkthrough__V1.0.md` | Exits with code 1 / `gate_block()` | UNPROVEN |
| `CisemATV.py` | `cisem_core/sandbox/CisemATV.py` | `2026-08-06__AntigravityLocal__YarivHuman__Gate_Hardening_Context_Adaptive_Layer_Ingestion_Sanitization_Persona_Coverage_Gaps_Resolution_Walkthrough__V1.0.md` | Exits with code 1 / `gate_block()` | UNPROVEN |